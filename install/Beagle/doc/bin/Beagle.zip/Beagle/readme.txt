Installation:

1) Download and install Java (if not already installed) from: 
   http://www.java.com/en/download/index.jsp   
  
2) Copy this folder at any location you like
  
2) start Beagle.exe
